package com.aerox.gamespace

import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var runButton: Button
    private lateinit var refresh90Button: Button
    private lateinit var refresh120Button: Button

    private val permissionRequestCode = 4107
    private val mlPackage = "com.mobile.legends"

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == permissionRequestCode) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                setStatus("Shizuku permission granted. Tap Check Status.")
                appendLog("Shizuku permission granted.")
            } else {
                setStatus("Shizuku permission denied.")
                appendLog("Permission denied. No privileged operation was run.")
            }
            updateButtons()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 12, 24)
        window.navigationBarColor = Color.rgb(8, 12, 24)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildUi()
        updateButtons()
        setStatus("Ready. Connect Shizuku, grant this app permission, then check status.")
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(Color.rgb(8, 12, 24))
        }
        scroll.addView(page)

        val title = TextView(this).apply {
            text = "GAME SPACE V2"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())
        page.addView(TextView(this).apply {
            text = "Vivo Y05 • MLBB performance tools"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(130, 190, 255))
            setPadding(0, dp(6), 0, dp(20))
        }, matchWrap())

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(230, 235, 245))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(22, 30, 48))
        }
        page.addView(status, matchWrap())

        page.addView(label("SHIZUKU / SYSTEM"))
        page.addView(actionButton("Request Shizuku Permission") { requestShizukuPermission() })
        runButton = actionButton("Check Status & Capabilities") { checkStatus() }
        page.addView(runButton)

        page.addView(label("DISPLAY REFRESH RATE (BEST EFFORT)"))
        refresh90Button = actionButton("Try 90 Hz") { applyRefreshRate(90) }
        page.addView(refresh90Button)
        refresh120Button = actionButton("Try 120 Hz") { applyRefreshRate(120) }
        page.addView(refresh120Button)
        page.addView(actionButton("Reset Refresh-Rate Overrides") { resetRefreshRate() })

        page.addView(label("MLBB PERFORMANCE MODE (BEST EFFORT)"))
        page.addView(actionButton("Try Android Game Mode: Performance") { tryGameMode() })
        page.addView(actionButton("Open MLBB") {
            val intent = packageManager.getLaunchIntentForPackage(mlPackage)
            if (intent != null) startActivity(intent)
            else appendLog("MLBB package not found: $mlPackage")
        })

        page.addView(label("RESULTS / HONEST STATUS"))
        logView = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(200, 215, 235))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(17, 22, 36))
            text = "No checks run yet."
        }
        page.addView(logView, matchWrap())
        page.addView(TextView(this).apply {
            text = "Important: these are best-effort system requests. Android/Vivo firmware or MLBB may ignore them. This app does not unlock unsupported FPS, alter game memory, or display fake FPS. It reports command output only."
            textSize = 12f
            setTextColor(Color.rgb(255, 205, 120))
            setPadding(0, dp(16), 0, dp(8))
        }, matchWrap())
        setContentView(scroll)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(Color.rgb(110, 170, 255))
        setPadding(0, dp(22), 0, dp(8))
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { action() }
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(31, 75, 135)))
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(8)
        layoutParams = p
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun setStatus(text: String) {
        status.text = text
    }

    private fun appendLog(message: String) {
        val old = if (::logView.isInitialized) logView.text.toString() else ""
        val next = (old + "\n\n" + message).trim()
        if (::logView.isInitialized) logView.text = next.takeLast(9000)
    }

    private fun hasBinder(): Boolean {
        return try { Shizuku.pingBinder() } catch (_: Exception) { false }
    }

    private fun hasPermission(): Boolean {
        return try {
            hasBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
    }

    private fun updateButtons() {
        val ok = hasPermission()
        if (::runButton.isInitialized) {
            runButton.isEnabled = ok
            refresh90Button.isEnabled = ok
            refresh120Button.isEnabled = ok
        }
    }

    private fun requestShizukuPermission() {
        if (!hasBinder()) {
            setStatus("Shizuku service is not running. Start it in the Shizuku app.")
            appendLog("Shizuku binder unavailable.")
            return
        }
        if (hasPermission()) {
            setStatus("Shizuku permission already granted.")
            appendLog("Permission already granted.")
            updateButtons()
            return
        }
        try {
            Shizuku.requestPermission(permissionRequestCode)
            setStatus("Permission request sent to Shizuku.")
        } catch (e: Exception) {
            setStatus("Could not request permission: ${e.message}")
        }
    }

    private fun runShell(command: String): String {
        if (!hasPermission()) return "ERROR: Shizuku permission not granted or service not running."
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val out = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val err = BufferedReader(InputStreamReader(process.errorStream)).readText()
            val code = process.waitFor()
            buildString {
                append("Command: ").append(command).append("\nExit code: ").append(code)
                if (out.isNotBlank()) append("\nOutput:\n").append(out.trim())
                if (err.isNotBlank()) append("\nError:\n").append(err.trim())
                if (out.isBlank() && err.isBlank()) append("\n(no output)")
            }
        } catch (e: Exception) {
            "ERROR running command: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun checkStatus() {
        if (!hasBinder()) {
            setStatus("Shizuku is not running.")
            appendLog("Start Shizuku and retry.")
            return
        }
        if (!hasPermission()) {
            setStatus("Shizuku is running, but this app has no permission yet.")
            requestShizukuPermission()
            return
        }
        setStatus("Shizuku connected and permission granted.")
        val commands = listOf(
            "getprop ro.build.version.release",
            "settings get system peak_refresh_rate",
            "settings get system min_refresh_rate",
            "settings get system user_refresh_rate",
            "cmd game list",
            "cmd game mode $mlPackage"
        )
        val result = commands.joinToString("\n\n----------------\n\n") { runShell(it) }
        appendLog("STATUS CHECK\n$result")
    }

    private fun applyRefreshRate(hz: Int) {
        if (hz !in listOf(60, 90, 120)) return
        val command = "settings put system peak_refresh_rate ${hz}.0; settings put system min_refresh_rate ${hz}.0; settings get system peak_refresh_rate; settings get system min_refresh_rate"
        val result = runShell(command)
        setStatus("Requested ${hz} Hz. Read the output and verify the actual active mode in Android display info.")
        appendLog("REFRESH RATE REQUEST ($hz Hz)\n$result\n\nNote: the vendor may ignore these settings or select a lower mode.")
    }

    private fun resetRefreshRate() {
        val result = runShell("settings delete system peak_refresh_rate; settings delete system min_refresh_rate; settings delete system user_refresh_rate; settings get system peak_refresh_rate; settings get system min_refresh_rate")
        setStatus("Removed refresh-rate overrides where permitted. Verify display settings afterward.")
        appendLog("RESET REFRESH-RATE OVERRIDES\n$result")
    }

    private fun tryGameMode() {
        val result = runShell("cmd game mode performance $mlPackage")
        setStatus("Sent best-effort Android Game Mode request. Check output; some Vivo builds do not implement this command.")
        appendLog("GAME MODE REQUEST\n$result\n\nThis does not modify MLBB files or guarantee a frame-rate increase.")
    }
}

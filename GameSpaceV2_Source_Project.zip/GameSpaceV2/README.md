# Game Space V2 (starter Android project)

A small Android Studio project for checking Shizuku access and trying limited, reversible, best-effort system requests relevant to gaming performance.

## What it actually does
- Requests Shizuku permission and checks whether the service is reachable.
- Reads a few system refresh-rate settings and Android Game Mode output.
- Tries 90 Hz / 120 Hz refresh-rate setting overrides, then prints the settings back.
- Offers a best-effort Android Game Mode performance request for `com.mobile.legends`.
- Shows command output rather than claiming a setting worked just because a command was sent.

## Important limitations
- This is source code, **not a prebuilt APK**.
- A successful shell command does not prove the screen is actually running at that refresh rate.
- Vivo firmware may ignore or overwrite settings; MLBB controls its own supported FPS options.
- Shizuku's ADB identity is not root and cannot grant every privileged operation.
- It does not measure rendered in-game FPS yet, unlock unsupported FPS, change protected game memory, or bypass anti-cheat.
- The project uses `Shizuku.newProcess`, which is deprecated in newer Shizuku API guidance; replace it with a UserService for a production-grade app.

## Build
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Open this folder as a project.
3. Let Gradle sync. Internet access is required to fetch Android Gradle Plugin, Kotlin, and Shizuku dependencies.
4. Build > Build APK(s).
5. Install the debug APK on your own phone, then open Shizuku and grant Game Space V2 permission.
6. Test one change at a time. If the display becomes unstable, use Reset Refresh-Rate Overrides and reboot if needed.

## Before trusting a result
Check the phone's active display mode / refresh rate independently while MLBB is open. Do not treat `settings get` output as proof of rendered FPS.
